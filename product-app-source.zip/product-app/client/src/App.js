import React from "react";
import ProductList from "./ProductList";

function App() {
  return (
    <div style={{ backgroundColor: "#1e1e1e", minHeight: "100vh", color: "#fff", padding: "20px" }}>
      <h2 style={{ textAlign: "center" }}>Product List</h2>
      <ProductList />
    </div>
  );
}

export default App;
