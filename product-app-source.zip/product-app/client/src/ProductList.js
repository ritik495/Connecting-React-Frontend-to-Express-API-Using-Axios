import React, { useEffect, useState } from "react";
import axios from "axios";

function ProductList() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios.get("/api/products")
      .then((res) => {
        setProducts(res.data);
        setLoading(false);
      })
      .catch(() => {
        setError("Failed to load products");
        setLoading(false);
      });
  }, []);

  if (loading) return <p style={{ textAlign: "center" }}>Loading...</p>;
  if (error) return <p style={{ textAlign: "center", color: "red" }}>{error}</p>;

  return (
    <div style={{ display: "flex", justifyContent: "center", gap: "20px", marginTop: "20px" }}>
      {products.map((product) => (
        <div
          key={product.id}
          style={{
            border: "1px solid #aaa",
            borderRadius: "10px",
            padding: "20px",
            width: "180px",
            textAlign: "center",
            backgroundColor: "#2c2c2c",
          }}
        >
          <h3>{product.name}</h3>
          <p>Price: ${product.price}</p>
          <button
            style={{
              backgroundColor: "#007bff",
              color: "white",
              border: "none",
              borderRadius: "5px",
              padding: "8px 16px",
              cursor: "pointer",
            }}
          >
            Buy Now
          </button>
        </div>
      ))}
    </div>
  );
}

export default ProductList;
